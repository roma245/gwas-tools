# diploma

dependencies:

1) boost

2) boost-python

3) boost-numpy

4) google sparse-hash

5) python

6) scikit-learn

7) numpy

8) matplotlib

9) pandas

10) jupyter

11) Cython

12) wget

13) pygco

14) xgboost

15) boruta

16) networkx

17) hyperopt

18) numba

how to run:

1) sudo sh install_dependencies.sh

1) make

2) LD_LIBRARY_PATH="/usr/local/lib" jupyter notebook

3) open testing_framework.ipynb
