rm cache/* -r
rm experiments_results/* -r
