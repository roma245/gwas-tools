import sys
from os import devnull
import pandas as pd
import numpy as np

filename = 'all_VCFs_merged_2017.csv'

# Open initial dataframe
df = pd.read_csv(filename, sep=',')

# Create copy of initial dataframe
df_res = pd.DataFrame(df)

# Set values in each column of the dataframe:
#   -> 0 if Sample call == Reference call
#   -> 1 if Sample call == Alternative call
#   -> "-" else (NA value)

for j in range(9, df_res.shape[1]):

    t_arr = [(df_res.iloc[:, j] != df_res.iloc[:, 3]) & (df_res.iloc[:, j] != df_res.iloc[:, 4])]

    zero_ind = np.where(t_arr)[1]
    df_res.set_value(zero_ind, df_res.columns[j], '-')


    t_arr = [df_res.iloc[:, j] == df_res.iloc[:, 3]]

    zero_ind = np.where(t_arr)[1]
    df_res.set_value(zero_ind, df_res.columns[j], '0')


    t_arr = [df_res.iloc[:, j] == df_res.iloc[:, 4]]

    zero_ind = np.where(t_arr)[1]
    df_res.set_value(zero_ind, df_res.columns[j], '1')


# Save converted dataframe
df_res.to_csv('Converted_'+filename, sep=',', index=False)


# Convert dataframe to snp matrix and save in snps.matrix format
#df_res = df_res.drop(df_res.columns[[0, 2, 3, 4, 5, 6, 7, 8]], axis=1)

df_res = df_res.drop(df_res.columns[[0, 2, 3, 5, 6, 7, 8]], axis=1)

# Add alternative nucleotide to position
df_res['POS'] = df_res['POS'].map(str)+'_'+df_res['ALT'].map(str)


df_res.transpose().to_csv('apr17.snps.matrix', sep='\t', index=True, header=False)
