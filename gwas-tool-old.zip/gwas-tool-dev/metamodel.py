from sklearn.base import BaseEstimator

from abc import ABCMeta, abstractmethod

from hyperopt import hp, STATUS_OK, STATUS_FAIL, Trials, fmin, tpe
from hyperopt.pyll import scope

import time
import traceback




class InnerModel:
    pass


class InnerModel1(InnerModel):
    pass


class InnerModel2(InnerModel):
    pass



class FeatureSelector:
    pass


class SimpleFeatureSelector(FeatureSelector):
    pass


class ComplexFeatureSelector(FeatureSelector):
    pass


### Factory for metamodel creation


class MetamodelFactory(BaseEstimator, ABCMeta):

    @abstractmethod
    def __init__(self,
                 inner_model=None,
                 feature_selector=None):
        self.inner_model = inner_model
        self.feature_selector = feature_selector


    @abstractmethod
    def set_inner_model(self):
        raise AttributeError('Not Implemented Model')

    @abstractmethod
    def set_feature_selector(self):
        raise AttributeError('Not Implemented Model')


### Common implementations of methods in metamodel


class Metamodel(MetamodelFactory):

    def __init__(self,
                 inner_model=None,
                 feature_selector=None,
                 results_dumper=None,
                 metrics_getter=None,
                 max_evals=100):
        super(Metamodel, self).__init__(
            inner_model = inner_model,
            feature_selector = feature_selector)
        # Set parameters
        self.results_dumper = results_dumper
        self.metrics_getter = metrics_getter
        self.max_evals = max_evals


    def fit(self, X, y, X_test=None):

        # Validate or convert input data
        #X = check_array(X, accept_sparse="csc", dtype=DTYPE)
        #y = check_array(y, accept_sparse='csc', ensure_2d=False, dtype=None)

        # Generate space of searched model from 'inner_model' and 'feature_selector'
        self.model_space = scope.get_complex_features_adder_wrapper(
            inner_model=inner_model,
            extender_strategy=feature_selector,
        )

        try:
            trials = Trials()
            best = fmin(
                fn=self.get_objective_function(
                    X,
                    y,
                    X_test,
                    callback=lambda result: self.results_dumper.add_result(result),
                ),
                space=self.model_space,
                algo=tpe.suggest,
                max_evals=self.max_evals,
                trials=trials
            )
            print best

            min_loss = 10.0

            for el in trials.results:
                if el['status'] == STATUS_OK:
                    if el['loss'] < min_loss:
                        self._result_model = el['model']
                        ####
                        self._result_metrics = el['full_metrics']

                        min_loss = el['loss']
            print self._result_model
        finally:
            self.results_dumper.flush()
        self._result_model.fit(X, y)
        return self


    # For given dataset (X, y, X_test) generate objective function with input argument 'model'
    def get_objective_function(self, X, y, X_test, callback=None):

        def objective_function(model):

            print "!OBJECTIVE"
            start_time = time.time()

            try:
                metrics, loss = self.metrics_getter(model, X, y, X_test)
                result = {
                    'status': STATUS_OK,
                    'loss': loss,
                    'full_metrics': metrics,
                    'time_calculated': time.time(),
                    'time_spent': time.time() - start_time,
                    'model': model,
                }
            except:
                with open(self.results_dumper.get_errors_log_filename(), "a") as f:
                    f.write(traceback.format_exc())
                    f.write("\n")
                    f.write(repr(model))
                    f.write("\n")
                result = {
                    'status': STATUS_FAIL,
                    'traceback': traceback.format_exc(),
                    'time_calculated': time.time(),
                    'time_spent': time.time() - start_time,
                    'model': model,
                }

            if callback is not None:
                callback(result)

            return result

        return objective_function



    def predict(self, X):
        return self._result_model.predict(X)

    def get_support(self, indices=False):
        return self._result_model.get_support(indices=indices)
        # return self._result_model.features_names

    def get_feature_importances(self):
        return self._result_model.get_feature_importances()


scope.define
def get_complex_features_adder_wrapper(*args, **kwargs):
    matrix_before_generating = get_ready_generator()[1]
    kwargs['matrix_before_generating'] = matrix_before_generating.as_matrix()
    kwargs['features_names'] = list(matrix_before_generating.columns.values)
    return ComplexFeaturesAdderWrapper(*args, **kwargs)


class ComplexFeaturesAdderWrapper(BaseEstimator):
    def __init__(self, inner_model, matrix_before_generating, features_names, extender_strategy):
        self.inner_model = inner_model
        self.matrix_before_generating = matrix_before_generating
        self.features_names = features_names
        self.extender_strategy = extender_strategy

    def _get_simple_features(self, indexes):
        return self.matrix_before_generating[indexes]

    def _fit_feature_extender(self, simple_features, y, indexes):
        self.extender_strategy.fit(simple_features, y, indexes)

    def _extend_features(self, simple_features):
        return self.extender_strategy.transform(simple_features)

    def fit(self, indexes=None, y=None, simple_features=None):
        indexes = indexes.ravel()
        if y is None:
            raise KeyError("y should be setted")
        if simple_features is None:
            simple_features = self._get_simple_features(indexes)
        else:
            simple_features = simple_features[self.features_names]
        self._fit_feature_extender(simple_features, y, indexes)
        extended_features = self._extend_features(simple_features)
        self.inner_model.fit(extended_features, y) # Possily should save fitted coefficients into file
        return self

    def predict(self, indexes=None, simple_features=None):
        if simple_features is None:
            if indexes is None:
                raise KeyError("either simple_features or indexes should be setted")
            indexes = indexes.ravel()
            simple_features = self._get_simple_features(indexes)
        extended_features = self._extend_features(simple_features)
        return self.inner_model.predict(extended_features)

    def get_support(self, indices=False):
        if indices == False:
            raise KeyError("indices should be true")
        extender_support = self.extender_strategy.get_support(indices=True, features_names=self.features_names)
        #extender_support = self.features_names
        return [extender_support[i] for i in self.inner_model.get_support(indices=True)]


    def get_feature_importances(self):
        return self.inner_model.get_feature_importances()



class MetamodelPrimitive1(Metamodel):
    def set_inner_model(self):
        self.inner_model = InnerModel1()

    def set_feature_selector(self):
        self.feature_selector = SimpleFeatureSelector()



class MetamodelPrimitive2(Metamodel):
    def set_inner_model(self):
        self.inner_model = InnerModel2()

    def set_feature_selector(self):
        self.feature_selector = SimpleFeatureSelector()

